package com.example.quiz

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

private val cream = Color.rgb(250,246,240)
private val rose = Color.rgb(211,151,163)
private val dark = Color.rgb(75,61,65)
private val lavender = Color.rgb(230,222,241)
private val beige = Color.rgb(239,225,208)

open class QuizBaseActivity : Activity() {
    lateinit var root: LinearLayout
    fun setup(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,22,22,22); setBackgroundColor(cream) }
        val scroll = ScrollView(this); scroll.addView(root)
        setContentView(scroll)
        text(title, 27, true, dark)
        if (subtitle != null) text(subtitle, 14, false, Color.rgb(130,111,116))
        space(16)
    }
    fun text(s:String, size:Int=16, bold:Boolean=false, color:Int=dark): TextView = TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD); setPadding(0,5,0,5); root.addView(this) }
    fun space(h:Int) { root.addView(View(this), LinearLayout.LayoutParams(1,h)) }
    fun button(s:String, color:Int=rose, action:()->Unit) { val b=Button(this).apply { text=s; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); textSize=15f; isAllCaps=false }; root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{topMargin=7;bottomMargin=7}); b.setOnClickListener{action()} }
    fun card(s:String, bg:Int=Color.WHITE, action:(()->Unit)?=null) { val t=TextView(this).apply { text=s; textSize=16f; setTextColor(dark); setPadding(16,15,16,15); setBackgroundColor(bg) }; root.addView(t,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=9}); if(action!=null)t.setOnClickListener{action()} }
    fun nav() { space(12); text("────────────────────────",12,false,rose); button("⌂  Beranda",rose){startActivity(Intent(this,DashboardActivity::class.java))}; button("▦  Kategori Kuis",rose){startActivity(Intent(this,CategoryActivity::class.java))}; button("◷  Riwayat",rose){startActivity(Intent(this,HistoryActivity::class.java))}; button("♡  Profil",rose){startActivity(Intent(this,ProfileActivity::class.java))} }
}

class CategoryActivity: QuizBaseActivity() { override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setup("Kategori Kuis 📚","Pilih mata kuliah yang ingin kamu pelajari."); val items=listOf("🗃️  Basis Data" to rose,"💻  Pemrograman Berorientasi Objek" to lavender,"📈  Sistem Informasi Manajemen" to beige,"🧩  Analisis dan Perancangan Sistem" to lavender,"🌐  Jaringan Komputer" to beige,"🗂️  Manajemen Proyek Sistem Informasi" to rose); items.forEach{(s,c)->card("$s\n10 soal  •  Pilihan ganda",c){startActivity(Intent(this,QuizActivity::class.java).putExtra("subject",s.substringAfter("  ")))}}; nav()} }

class QuizActivity: QuizBaseActivity() {
 private val questions=listOf("Apa kepanjangan dari DBMS?","Manakah yang termasuk perintah SQL untuk mengambil data?","Apa fungsi primary key?")
 private val options=listOf(listOf("Database Management System","Digital Base Main Server","Data Backup Memory System","Database Model Software"),listOf("SELECT","PAUSE","PRINT","OPEN"),listOf("Mengidentifikasi baris secara unik","Menghapus seluruh tabel","Mengubah warna tabel","Membuat jaringan"))
 private val correct=listOf(0,0,0); private var index=0; private var score=0; private var chosen=-1; private lateinit var questionView:TextView; private lateinit var choices:LinearLayout; private lateinit var next:Button
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); setup("Mulai Kuis ✨",intent.getStringExtra("subject")?:"Basis Data"); text("Pilih jawaban yang paling tepat. Kerjakan dengan santai ya!"); space(10); questionView=text("",20,true); choices=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; root.addView(choices); next=Button(this).apply{text="Jawaban berikutnya";isAllCaps=false};root.addView(next); next.setOnClickListener{if(chosen<0){Toast.makeText(this,"Pilih jawaban dulu ya",Toast.LENGTH_SHORT).show()}else{if(chosen==correct[index])score++;index++;if(index>=questions.size){startActivity(Intent(this,ResultActivity::class.java).putExtra("score",score).putExtra("total",questions.size));finish()}else showQuestion()}}; showQuestion() }
 private fun showQuestion(){chosen=-1; questionView.text="Soal ${index+1} dari ${questions.size}\n${questions[index]}"; choices.removeAllViews();options[index].forEachIndexed{n,s->val b=RadioButton(this).apply{text=s;textSize=15f;setTextColor(dark);setPadding(8,8,8,8)};choices.addView(b);b.setOnClickListener{chosen=n;for(i in 0 until choices.childCount)(choices.getChildAt(i) as RadioButton).isChecked=i==n}};next.text=if(index==questions.lastIndex)"Lihat hasil" else "Jawaban berikutnya"}
}
class ResultActivity: QuizBaseActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val score=intent.getIntExtra("score",0);val total=intent.getIntExtra("total",3);getSharedPreferences("quiz_session",MODE_PRIVATE).edit().putInt("last_score",score).putInt("last_total",total).apply();setup("Hasil Kuis 🏆","Kamu sudah menyelesaikan latihan!");text("$score / $total",42,true,rose);text("Nilai: ${score*100/total}",23,true);card(if(score==total)"Hebat! Semua jawaban benar. Pertahankan ya! 🌸" else "Tetap semangat! Belajar sedikit demi sedikit akan membantu.",lavender);button("Coba lagi"){startActivity(Intent(this,QuizActivity::class.java));finish()};button("Kembali ke beranda"){startActivity(Intent(this,DashboardActivity::class.java));finish()};nav()} }
class HistoryActivity:QuizBaseActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setup("Riwayat Belajar 📊","Ringkasan latihan di perangkat ini.");val p=getSharedPreferences("quiz_session",MODE_PRIVATE);if(p.contains("last_score")){val sc=p.getInt("last_score",0);val total=p.getInt("last_total",3);card("📝  Kuis latihan\nSkor: $sc dari $total\nNilai: ${sc*100/total}",lavender)}else card("Belum ada riwayat kuis. Yuk, mulai latihan pertamamu!",beige);button("Mulai kuis"){startActivity(Intent(this,CategoryActivity::class.java))};nav()} }
class ProfileActivity:QuizBaseActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setup("Profil Saya 👤","Ruang personal untuk perjalanan belajarmu.");val p=getSharedPreferences("quiz_session",MODE_PRIVATE);card("🌷\n${p.getString("nama","Mahasiswa")?:"Mahasiswa"}\n${p.getString("email","Belum login")?:"Belum login"}",lavender);card("✨  Terus belajar, terus bertumbuh.\nSistem Informasi • Quiz App",beige);button("Keluar dari akun"){p.edit().clear().apply();val i=Intent(this,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish()};nav()} }
