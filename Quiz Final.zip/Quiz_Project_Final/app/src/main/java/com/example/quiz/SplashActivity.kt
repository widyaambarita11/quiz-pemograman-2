package com.example.quiz

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        Handler(Looper.getMainLooper()).postDelayed({
            val prefs = getSharedPreferences("quiz_session", MODE_PRIVATE)
            val destination = if (prefs.getBoolean("logged_in", false)) {
                DashboardActivity::class.java
            } else {
                MainActivity::class.java
            }
            startActivity(Intent(this, destination))
            finish()
        }, 1200)
    }
}
