package com.example.quiz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        val prefs = getSharedPreferences("quiz_session", MODE_PRIVATE)
        findViewById<TextView>(R.id.tvWelcome).text = "Haii! 👋"
        findViewById<TextView>(R.id.tvProfile).text = "Nama: ${prefs.getString("nama", "-")}\nEmail: ${prefs.getString("email", "-")}\nID akun: ${prefs.getInt("user_id", 0)}"
        val container = findViewById<android.view.ViewGroup>(android.R.id.content).getChildAt(0) as? android.view.ViewGroup
        val extra = android.widget.Button(this).apply { text = "📚  Lihat Semua Kategori Kuis"; isAllCaps = false }
        extra.setOnClickListener { startActivity(Intent(this, CategoryActivity::class.java)) }
        container?.let { if (it is android.widget.ScrollView) { (it.getChildAt(0) as? android.view.ViewGroup)?.addView(extra) } else it.addView(extra) }
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            prefs.edit().clear().apply()
            val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
            finish()
        }
    }
}
